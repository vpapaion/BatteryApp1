package com.example.batterydisplay;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {

    private final Handler handler = new Handler(Looper.getMainLooper());

    private TextView timeView;
    private TextView batteryView;
    private TextView chargingView;
    private TextView updateView;
    private LinearLayout root;

    private boolean liveUpdate = true;

    private final Runnable refreshRunnable = new Runnable() {
        @Override
        public void run() {
            updateScreen();
            handler.postDelayed(this, 1000L); // refresh every 1 second
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        buildUi();
        updateScreen();
    }

    @Override
    protected void onResume() {
        super.onResume();
        liveUpdate = true;
        handler.removeCallbacks(refreshRunnable);
        handler.post(refreshRunnable);
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Stop updates when app is not visible, to avoid wasting battery.
        handler.removeCallbacks(refreshRunnable);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacks(refreshRunnable);
        super.onDestroy();
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(32, 32, 32, 32);

        timeView = new TextView(this);
        timeView.setGravity(Gravity.CENTER);
        timeView.setTextSize(44f);
        timeView.setTextColor(Color.WHITE);
        timeView.setText("--:--:--");

        batteryView = new TextView(this);
        batteryView.setGravity(Gravity.CENTER);
        batteryView.setTextSize(100f);
        batteryView.setTextColor(Color.WHITE);
        batteryView.setText("--%");

        chargingView = new TextView(this);
        chargingView.setGravity(Gravity.CENTER);
        chargingView.setTextSize(32f);
        chargingView.setTextColor(Color.WHITE);
        chargingView.setText("---");

        updateView = new TextView(this);
        updateView.setGravity(Gravity.CENTER);
        updateView.setTextSize(18f);
        updateView.setTextColor(Color.WHITE);
        updateView.setText("Last update: --:--:--");

        Button refreshButton = new Button(this);
        refreshButton.setText("Refresh now");
        refreshButton.setTextSize(18f);
        refreshButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                updateScreen();
            }
        });

        Button exitButton = new Button(this);
        exitButton.setText("Exit");
        exitButton.setTextSize(18f);
        exitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        buttons.setGravity(Gravity.CENTER);
        buttons.addView(refreshButton, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        buttons.addView(exitButton, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        root.addView(timeView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        root.addView(spacer(28));
        root.addView(batteryView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        root.addView(spacer(12));
        root.addView(chargingView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        root.addView(spacer(20));
        root.addView(updateView, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));
        root.addView(spacer(28));
        root.addView(buttons, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        setContentView(root);
    }

    private View spacer(int heightDp) {
        View view = new View(this);
        int px = (int) (heightDp * getResources().getDisplayMetrics().density);
        view.setLayoutParams(new LinearLayout.LayoutParams(1, px));
        return view;
    }

    private void updateScreen() {
        if (!liveUpdate) return;

        BatteryInfo info = readBatteryInfo();
        String now = getCurrentTime();

        timeView.setText(now);
        batteryView.setText(info.level + "%");
        chargingView.setText(info.statusText);
        updateView.setText("Last update: " + now);

        int bgColor;
        int textColor;

        if (info.level < 20) {
            bgColor = Color.rgb(176, 0, 32);       // red
            textColor = Color.WHITE;
        } else if (info.level < 70) {
            bgColor = Color.rgb(255, 193, 7);      // yellow
            textColor = Color.BLACK;
        } else {
            bgColor = Color.rgb(27, 142, 62);      // green
            textColor = Color.WHITE;
        }

        root.setBackgroundColor(bgColor);
        timeView.setTextColor(textColor);
        batteryView.setTextColor(textColor);
        chargingView.setTextColor(textColor);
        updateView.setTextColor(textColor);
    }

    private BatteryInfo readBatteryInfo() {
        BatteryManager batteryManager = (BatteryManager) getSystemService(Context.BATTERY_SERVICE);
        int level = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);

        Intent batteryIntent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));

        if (level < 0 || level > 100) {
            int rawLevel = batteryIntent != null ? batteryIntent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
            int scale = batteryIntent != null ? batteryIntent.getIntExtra(BatteryManager.EXTRA_SCALE, -1) : -1;
            if (rawLevel >= 0 && scale > 0) {
                level = (rawLevel * 100) / scale;
            } else {
                level = 0;
            }
        }

        int status = batteryIntent != null ? batteryIntent.getIntExtra(BatteryManager.EXTRA_STATUS, -1) : -1;
        int plugged = batteryIntent != null ? batteryIntent.getIntExtra(BatteryManager.EXTRA_PLUGGED, 0) : 0;

        boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                || status == BatteryManager.BATTERY_STATUS_FULL;

        String statusText;
        if (status == BatteryManager.BATTERY_STATUS_FULL) {
            statusText = "Full";
        } else if (charging && plugged == BatteryManager.BATTERY_PLUGGED_AC) {
            statusText = "Charging AC";
        } else if (charging && plugged == BatteryManager.BATTERY_PLUGGED_USB) {
            statusText = "Charging USB";
        } else if (charging && plugged == BatteryManager.BATTERY_PLUGGED_WIRELESS) {
            statusText = "Wireless charging";
        } else if (charging) {
            statusText = "Charging";
        } else {
            statusText = "Not charging";
        }

        return new BatteryInfo(clamp(level), statusText);
    }

    private int clamp(int value) {
        if (value < 0) return 0;
        if (value > 100) return 100;
        return value;
    }

    private String getCurrentTime() {
        return new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
    }

    private static class BatteryInfo {
        final int level;
        final String statusText;

        BatteryInfo(int level, String statusText) {
            this.level = level;
            this.statusText = statusText;
        }
    }
}
