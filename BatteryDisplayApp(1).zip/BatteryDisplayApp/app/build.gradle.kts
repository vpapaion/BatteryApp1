plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.batterydisplay"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.batterydisplay"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
